﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Fiestas.WPF
{
    /// <summary>
    /// Lógica de interacción para MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            Menuprincipal.OpcionSeleccionada += (se, ev) =>
            {
                switch (ev)
                {
                    case "Clientes":
                        Capa_Presentacion.Clientes.AdmonClientesUC clienteControl = new Capa_Presentacion.Clientes.AdmonClientesUC();
                        AreaTrabajoGrid.Children.Clear();
                        AreaTrabajoGrid.Children.Add(clienteControl);
                        AreaTrabajoGrid.Visibility = Visibility.Visible;
                        clienteControl.Regresar += (sen, eve) =>
                          {
                              regresarMenu();
                          };
                        break;
                    case "Paquetes":
                        Capa_Presentacion.Paquetes.AdmonPaquetesUC paqueteControl = new Capa_Presentacion.Paquetes.AdmonPaquetesUC();
                        AreaTrabajoGrid.Children.Clear();
                        AreaTrabajoGrid.Children.Add(paqueteControl);
                        AreaTrabajoGrid.Visibility = Visibility.Visible;
                        paqueteControl.Regresar += (sen, eve) =>
                        {
                            regresarMenu();
                        };
                        break;
                    case "Eventos":
                        Capa_Presentacion.Eventos.AdmonEventosUC eventoControl = new Capa_Presentacion.Eventos.AdmonEventosUC();
                        AreaTrabajoGrid.Children.Clear();
                        AreaTrabajoGrid.Children.Add(eventoControl);
                        AreaTrabajoGrid.Visibility = Visibility.Visible;
                        eventoControl.Regresar += (sen, eve) =>
                        {
                            regresarMenu();
                        };
                        break;
                    case "Productos":
                        Capa_Presentacion.Productos.AdmonProductosUC productoControl = new Capa_Presentacion.Productos.AdmonProductosUC();
                        AreaTrabajoGrid.Children.Clear();
                        AreaTrabajoGrid.Children.Add(productoControl);
                        AreaTrabajoGrid.Visibility = Visibility.Visible;
                        productoControl.Regresar += (sen, eve) =>
                        {
                            regresarMenu();
                        };
                        break;
                    default:
                        break;
                }
            };
         }

        private void regresarMenu()
        {
            AreaTrabajoGrid.Children.Clear();
            AreaTrabajoGrid.Visibility = Visibility.Collapsed;
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            Capa_Presentacion.Seguridad.LoginWindow login = new Capa_Presentacion.Seguridad.LoginWindow();
            login.UsuarioEncontrado += (se, ev) =>
            {
                login.Close();
            };
            login.ShowDialog();
            
        }
    }
}

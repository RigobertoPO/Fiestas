﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Fiestas.WPF.Capa_Presentacion.Controles
{
    /// <summary>
    /// Lógica de interacción para BotonMenuUC.xaml
    /// </summary>
    public partial class BotonMenuUC : UserControl
    {
        public BotonMenuUC()
        {
            InitializeComponent();
        }
        public event EventHandler Click;
        private void BotonCanvas_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            if (Click != null) Click(this, new EventArgs());
        }

        #region PROPIEDADES
        /// <summary>
        /// Titulo o Nombre mostrado para el Tile
        /// </summary>
        [DefaultValue("Titulo Tile")]
        public string Titulo
        {
            get { return (string)GetValue(TituloProperty); }
            set { SetValue(TituloProperty, value); }
        }
        public static readonly DependencyProperty TituloProperty =
            DependencyProperty.Register("Titulo", typeof(string), typeof(BotonMenuUC),
            new PropertyMetadata((d, e) =>
            {
                if (e.NewValue != null) ((BotonMenuUC)d).TituloTextBlock.Text = e.NewValue.ToString();
            }));
        #endregion
    }
}

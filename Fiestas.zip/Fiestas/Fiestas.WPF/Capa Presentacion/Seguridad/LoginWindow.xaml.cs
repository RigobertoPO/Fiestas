﻿using Fiestas.WPF.Capa_Datos;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Fiestas.WPF.Capa_Presentacion.Seguridad
{
    /// <summary>
    /// Lógica de interacción para LoginWindow.xaml
    /// </summary>
    public partial class LoginWindow : Window
    {
        public LoginWindow()
        {
            InitializeComponent();
        }
        #region PROPIEDADES
        public delegate void UsuarioEventArgs(object o, Usuario u);
        public UsuarioEventArgs UsuarioEncontrado;
      
        #endregion
        private void EntrarButton_Click(object sender, RoutedEventArgs e)
        {
            Capa_Logica.SeguridadMetodos contextSeguridad = new Capa_Logica.SeguridadMetodos();
            var _usuario = contextSeguridad.Autenticar(LoginTextBox.Text, PasswordTextBox.Password);
            if (_usuario != null)
            {
                if (UsuarioEncontrado != null) UsuarioEncontrado(this, _usuario);
            }
            else
            {
                MessageBox.Show("Usuario o contraseña invalida");
            }
           
        }
    }
}

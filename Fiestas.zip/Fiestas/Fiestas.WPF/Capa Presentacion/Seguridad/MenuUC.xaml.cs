﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Fiestas.WPF.Capa_Presentacion.Seguridad
{
    /// <summary>
    /// Lógica de interacción para MenuUC.xaml
    /// </summary>
    public partial class MenuUC : UserControl
    {
        public MenuUC()
        {
            InitializeComponent();
        }

        public delegate void opcionEventArgs(object o, string u);
        public opcionEventArgs OpcionSeleccionada;
        public event EventHandler Click;
        private void ClientesBoton_Click(object sender, EventArgs e)
        {
            if (OpcionSeleccionada != null) OpcionSeleccionada(this, "Clientes");
        }

        private void PaquetesBoton_Click(object sender, EventArgs e)
        {
            if (OpcionSeleccionada != null) OpcionSeleccionada(this, "Paquetes");
        }

        private void EventosBoton_Click(object sender, EventArgs e)
        {
            if (OpcionSeleccionada != null) OpcionSeleccionada(this, "Eventos");
        }

        private void ProductosBoton_Click(object sender, EventArgs e)
        {
            if (OpcionSeleccionada != null) OpcionSeleccionada(this, "Productos");
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Fiestas.WPF.Capa_Presentacion.Paquetes
{
    /// <summary>
    /// Lógica de interacción para AdmonPaquetesUC.xaml
    /// </summary>
    public partial class AdmonPaquetesUC : UserControl
    {
        public AdmonPaquetesUC()
        {
            InitializeComponent();
        }

        public event EventHandler Regresar;
        private void Image_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            if (Regresar != null) Regresar(this, new EventArgs());
        }
    }
}

﻿using Fiestas.WPF.Capa_Datos;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Fiestas.WPF.Capa_Logica
{
    public class SeguridadMetodos
    {
        #region USUARIOS
        public Usuario Autenticar(string login, string password)
        {
            var _usuario = new Usuario();

            using (var conexion = new Capa_Datos.FiestasBDEntities())
            {
                _usuario = (from c in conexion.Usuarios where c.Login == login && c.Password == password select c).FirstOrDefault();
                return _usuario;
            }
        }

        #endregion

    }
}
